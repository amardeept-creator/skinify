import { getCloudflareContext } from '@opennextjs/cloudflare';
import { storageDriver } from '@/lib/server/storage';
const TYPES: Record<string, string> = { glb: 'model/gltf-binary', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', mp4: 'video/mp4', webm: 'video/webm' };

export async function GET(req: Request, ctx: { params: Promise<{ key: string[] }> }) {
  const key = (await ctx.params).key.join('/');
  if (!/^[\w\-/.]+$/.test(key) || key.includes('..')) return new Response('Bad key', { status: 400 });
  try {
    if (storageDriver() === 'r2') {
      const { env } = getCloudflareContext() as any;
      const obj = await env.SKINIFY_ASSETS.get(key);
      if (!obj) return new Response('Not found', { status: 404 });
      const headers = new Headers();
      headers.set('content-type', obj.httpMetadata?.contentType || TYPES[key.split('.').pop() || ''] || 'application/octet-stream');
      headers.set('cache-control', 'public, max-age=31536000, immutable');
      headers.set('x-content-type-options', 'nosniff');
      headers.set('etag', obj.httpEtag);
      return new Response(obj.body, { headers });
    }
    return new Response('Not found', { status: 404 });
  } catch { return new Response('Not found', { status: 404 }); }
}
