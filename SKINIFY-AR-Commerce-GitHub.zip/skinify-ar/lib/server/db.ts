import 'server-only';
import { neon, Pool } from '@neondatabase/serverless';

type TaggedSql = any;

let cachedUrl: string | null = null;
let cachedSql: TaggedSql | null = null;

function databaseUrl() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL is not configured. See .env.example.');
  return url;
}

function getSql(): TaggedSql {
  const url = databaseUrl();
  if (!cachedSql || cachedUrl !== url) {
    cachedUrl = url;
    cachedSql = neon(url) as TaggedSql;
    cachedSql.json = (value: unknown) => JSON.stringify(value);
    cachedSql.begin = async (fn: (tx: TaggedSql) => Promise<unknown>) => {
      const pool = new Pool({ connectionString: url, max: 1 });
      const client = await pool.connect();
      const tx = ((strings: TemplateStringsArray, ...values: unknown[]) => {
        return client.query(...buildQuery(strings, values)).then((r: { rows: unknown[] }) => r.rows);
      }) as TaggedSql;
      tx.json = (value: unknown) => JSON.stringify(value);
      try {
        await client.query('BEGIN');
        const result = await fn(tx);
        await client.query('COMMIT');
        return result;
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch {}
        throw error;
      } finally {
        client.release();
        await pool.end();
      }
    };
  }
  return cachedSql;
}

function buildQuery(strings: TemplateStringsArray, values: unknown[]): [string, unknown[]] {
  let text = strings[0] || '';
  const params: unknown[] = [];
  for (let i = 0; i < values.length; i++) {
    text += `$${params.length + 1}${strings[i + 1] || ''}`;
    params.push(values[i]);
  }
  return [text, params];
}

/** Neon serverless driver is used instead of postgres.js because Cloudflare Workers do not provide raw TCP sockets. */
export const sql: TaggedSql = new Proxy(function () {} as unknown as TaggedSql, {
  apply: (_target, _this, args) => getSql()(...args),
  get: (_target, property) => getSql()[property],
});
