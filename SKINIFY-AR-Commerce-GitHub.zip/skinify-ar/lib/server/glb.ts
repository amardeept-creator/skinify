import 'server-only';

export interface GlbReport {
  ok: boolean; error?: string; warnings: string[];
  bytesIn: number; bytesOut: number; optimized: boolean;
  bbox?: { min: number[]; max: number[]; size: number[] };
  triangles: number; meshes: number; materials: string[]; textures: number; maxTextureSize: number; extensions: string[];
}

const MAX_TRIS = 400_000;

function readJsonChunk(buf: Uint8Array): any | null {
  if (buf.length < 20) return null;
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let offset = 12;
  while (offset + 8 <= buf.length) {
    const length = dv.getUint32(offset, true);
    const type = dv.getUint32(offset + 4, true);
    const start = offset + 8;
    const end = start + length;
    if (end > buf.length) return null;
    if (type === 0x4e4f534a) return JSON.parse(new TextDecoder().decode(buf.subarray(start, end)));
    offset = end;
  }
  return null;
}

export function sniffGlb(buf: Uint8Array): string | null {
  if (buf.length < 20) return 'File is too small to be a GLB.';
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  if (dv.getUint32(0, true) !== 0x46546c67) return 'Not a GLB file (missing glTF header). Export your model as .glb (binary glTF 2.0).';
  if (dv.getUint32(4, true) !== 2) return 'Only glTF 2.0 is supported.';
  if (dv.getUint32(8, true) !== buf.length) return 'GLB length header does not match the file size (corrupt upload?).';
  if (dv.getUint32(16, true) !== 0x4e4f534a) return 'GLB is missing its JSON chunk.';
  return null;
}

/** Cloudflare-safe GLB inspection. It deliberately avoids Node-only glTF-transform filesystem APIs. */
export async function processGlb(input: Uint8Array): Promise<{ report: GlbReport; output: Uint8Array }> {
  const warnings: string[] = [];
  const base: GlbReport = { ok: false, warnings, bytesIn: input.length, bytesOut: input.length, optimized: false, triangles: 0, meshes: 0, materials: [], textures: 0, maxTextureSize: 0, extensions: [] };
  const sniff = sniffGlb(input);
  if (sniff) return { report: { ...base, error: sniff }, output: input };
  let json: any;
  try { json = readJsonChunk(input); } catch (e) { return { report: { ...base, error: `Invalid GLB JSON chunk: ${String(e).slice(0, 160)}` }, output: input }; }
  if (!json) return { report: { ...base, error: 'GLB JSON chunk could not be read.' }, output: input };

  const meshes = Array.isArray(json.meshes) ? json.meshes : [];
  const accessors = Array.isArray(json.accessors) ? json.accessors : [];
  let triangles = 0;
  for (const mesh of meshes) for (const primitive of mesh.primitives || []) {
    if ((primitive.mode ?? 4) !== 4) continue;
    const idx = primitive.indices != null ? accessors[primitive.indices] : null;
    const pos = primitive.attributes?.POSITION != null ? accessors[primitive.attributes.POSITION] : null;
    triangles += Math.floor((idx?.count ?? pos?.count ?? 0) / 3);
  }
  if (triangles > MAX_TRIS) return { report: { ...base, triangles, meshes: meshes.length, error: `Model has ${Math.round(triangles).toLocaleString()} triangles; the limit is ${MAX_TRIS.toLocaleString()}. Please decimate it for mobile AR.` }, output: input };

  const materials = (json.materials || []).map((m: any) => m.name || '').filter(Boolean);
  const extensions = [...new Set([...(json.extensionsUsed || []), ...(json.extensionsRequired || [])])];
  if (extensions.some((x: string) => /draco/i.test(x))) warnings.push('Draco compression detected; the original GLB is kept as uploaded.');
  if (triangles > 150_000) warnings.push('High polygon count may reduce frame rate on older phones.');
  const maxTextureSize = 0;
  if ((json.images || []).length > 0) warnings.push('Texture dimensions are not decoded server-side on Cloudflare; validate mobile texture sizes before publishing.');
  warnings.push('Cloudflare build keeps the original GLB instead of Node-only server re-optimisation.');

  return { report: { ...base, ok: true, bytesOut: input.length, optimized: false, triangles, meshes: meshes.length, materials, textures: (json.textures || []).length, maxTextureSize, extensions, warnings }, output: input };
}

export function sniffImage(buf: Uint8Array): string | null {
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 && buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50) return 'image/webp';
  return null;
}
export function sniffVideo(buf: Uint8Array): string | null {
  if (buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70) return 'video/mp4';
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  return null;
}

/** Self-contained .gltf is accepted only when it is already a binary GLB. For predictable Workers uploads, sellers should export .glb. */
export async function gltfJsonToGlb(_buf: Uint8Array): Promise<Uint8Array> {
  throw new Error('For Cloudflare deployment, upload a single binary .glb file. External .gltf conversion is disabled in the Worker runtime.');
}
