import 'server-only';
import { getCloudflareContext } from '@opennextjs/cloudflare';
import { siteUrl } from '@/lib/format';

export type Driver = 'r2' | 'none';

type R2Like = {
  put: (key: string, value: unknown, options?: Record<string, unknown>) => Promise<unknown>;
  get: (key: string, options?: Record<string, unknown>) => Promise<any>;
  delete: (key: string) => Promise<void>;
};

type CFEnv = { SKINIFY_ASSETS?: R2Like };

function r2(): R2Like | null {
  try {
    const env = getCloudflareContext().env as unknown as CFEnv;
    return env?.SKINIFY_ASSETS || null;
  } catch {
    return null;
  }
}

export function storageDriver(): Driver { return r2() ? 'r2' : 'none'; }

export async function putObject(key: string, body: Uint8Array, contentType: string) {
  const bucket = r2();
  if (!bucket) throw new Error('STORAGE_NOT_CONFIGURED');
  await bucket.put(key, body, {
    httpMetadata: { contentType, cacheControl: 'public, max-age=31536000, immutable' },
    customMetadata: { app: 'skinify' },
  });
  const publicBase = (process.env.NEXT_PUBLIC_R2_PUBLIC_URL || siteUrl()).replace(/\/$/, '');
  const url = process.env.NEXT_PUBLIC_R2_PUBLIC_URL ? `${publicBase}/${key}` : `${publicBase}/api/files/${key}`;
  return { key, url };
}

export async function deleteObject(url: string, key?: string) {
  try {
    const bucket = r2();
    if (!bucket) return;
    let objectKey = key;
    if (!objectKey && url.includes('/api/files/')) objectKey = decodeURIComponent(url.split('/api/files/')[1]);
    if (objectKey) await bucket.delete(objectKey);
  } catch (e) { console.warn('[storage] delete failed', e); }
}
