'use client';
export type Kind = 'model' | 'image' | 'video';
// Cloudflare Workers accepts request bodies up to 100 MB on Free/Pro; plan entitlements still cap each upload.
export const DIRECT_MAX = 100 * 1048576;
export interface UploadedAsset { id: string; kind: Kind; url: string; mime: string; bytes: number; original_bytes: number; original_filename: string; meta: Record<string, unknown> }
/** Cloudflare/R2 path: multipart upload to the Worker, then persistence in R2. */
export async function uploadAsset(file: File, kind: Kind, onProgress?: (p: number) => void): Promise<UploadedAsset> {
  const ext = file.name.split('.').pop()?.toLowerCase();
  if (kind === 'model' && ext !== 'glb') throw new Error('For Cloudflare AR, 3D models must be a single .glb file.');
  if (file.size > DIRECT_MAX) throw new Error('This file is larger than the Cloudflare request limit. Please use a smaller optimized asset.');
  const fd = new FormData(); fd.append('file', file); fd.append('kind', kind);
  onProgress?.(0.1);
  const r = await fetch('/api/assets', { method: 'POST', body: fd });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Upload failed');
  onProgress?.(1); return d.asset;
}
