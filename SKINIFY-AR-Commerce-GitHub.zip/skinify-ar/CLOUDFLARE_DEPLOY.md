# SKINIFY — Cloudflare Workers deployment (no local Wrangler installation)

This project is converted for Cloudflare Workers using the OpenNext Cloudflare adapter.
You do **not** need to install Wrangler globally. Wrangler is included as a project dev dependency and Cloudflare Workers Builds can run it automatically.

## 1. Create R2 bucket

In Cloudflare Dashboard → R2 → Create bucket → name it:

`skinify-assets`

The included `wrangler.jsonc` binds this bucket as `SKINIFY_ASSETS`.

## 2. Connect the repository

Push this folder to GitHub/GitLab and create a Cloudflare Worker from Workers & Pages → Create → Import repository.

Recommended Workers Builds settings:

- Build command: `npm run build:cloudflare`
- Deploy command: `npm run deploy:cloudflare`
- Root directory: `/`

Wrangler is resolved from the project's dependencies; there is no global Wrangler installation requirement.

## 3. Add runtime variables/secrets

Add these in Worker → Settings → Variables and Secrets:

- `DATABASE_URL` — Neon PostgreSQL connection string
- `NEXT_PUBLIC_SITE_URL` — final Worker URL, e.g. `https://skinify-ar.<your-subdomain>.workers.dev`
- `NEXT_PUBLIC_R2_PUBLIC_URL` — optional R2 custom/public URL. Leave blank to serve uploaded assets through `/api/files/...`.
- `STRIPE_SECRET_KEY` — optional
- `STRIPE_WEBHOOK_SECRET` — optional
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — only if seeding via a Node environment

Neon is accessed through `@neondatabase/serverless`, which is designed for Cloudflare Workers/edge environments.

## 4. Database

Run `db/schema.sql` against the existing Neon database if the schema is not already present. The existing data is not moved by this source-code conversion.

## 5. 3D assets

For the Cloudflare build, sellers upload a single `.glb` file. The Worker validates the GLB and stores the original model in R2. Node-only glTF Transform server optimisation has been removed from the Worker runtime so the AR upload path remains compatible with Workers.

## 6. Important

This is a Workers deployment, not a static Cloudflare Pages export. The seller dashboard, API routes, authentication, Neon database, subscriptions, public Skinner links and AR client continue to run as a full-stack Worker.
