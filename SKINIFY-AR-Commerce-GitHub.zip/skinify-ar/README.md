# SKINIFY — Try it. Before you buy it.

SKINIFY is an AR commerce platform: brands turn products into **Skinners** (browser-based AR try-on experiences) and share them anywhere with a link, QR code or embed; customers discover products and try them on with their camera — no app, no account.

> SKINIFY is **not** a skin-analysis, dermatology or skincare product. It performs no diagnosis or medical analysis of any kind.

## Stack

| Layer | Choice |
| --- | --- |
| App | Next.js 15 (App Router, React 19, TypeScript), deployed on Vercel |
| Database | PostgreSQL (Neon in production; any Postgres locally) via `postgres` driver |
| File storage | Vercel Blob (client uploads up to plan limit; server-side optimisation) |
| AR tracking | MediaPipe Tasks Vision (hand / face / pose / segmentation), on-device, WebGL/WASM |
| Rendering | Three.js (PBR materials, Draco + Meshopt decoding, depth occluders, camera-based light estimation) |
| 3D pipeline | glTF-Transform + meshoptimizer (validate → inspect → dedup/prune → compress) |
| Billing | Stripe Checkout + signed webhooks (optional — disabled until keys are set) |

## Project layout

```
app/(site)          customer pages: home, explore, categories, brands, product, brand store, saved, pricing, docs
app/s/[slug]        public Skinner link (full-screen AR)      app/embed/[slug]  iframe embed
app/try/[b]/[p]     readable alias → /s/[slug]                 app/(auth)        login / signup
app/onboarding      seller onboarding (brand → first Skinner)  app/dashboard/*   seller studio
app/admin           platform admin                             app/api/*         JSON APIs (+ /api/v1 public API)
lib/ar/*            BODY-PART AR TRACKING ENGINE (config, vision loader, solvers, filters, nails, engine, viewer)
lib/server/*        db, auth, sessions, rate limit, storage, GLB validation, entitlements, links, analytics
db/schema.sql       full schema     scripts/migrate.mjs, scripts/seed.ts
```

## Local development

```bash
npm install
cp .env.example .env.local        # set DATABASE_URL (any Postgres 14+)
npm run db:migrate                # creates tables (idempotent)
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-strong-one' DEMO_SELLER_PASSWORD='another-one' npm run db:seed
npm run dev                       # http://localhost:3000
```

Camera access requires HTTPS or `localhost`. Uploads are stored in `.data/` locally when no Blob token is configured.

## Cloudflare Workers deployment

This distribution is configured for Cloudflare Workers using OpenNext. It uses Neon through `@neondatabase/serverless` and Cloudflare R2 for persistent uploaded assets. See `CLOUDFLARE_DEPLOY.md`.

No global Wrangler installation is required. Wrangler is included as a project dev dependency and Cloudflare Workers Builds can run the project deployment command.
